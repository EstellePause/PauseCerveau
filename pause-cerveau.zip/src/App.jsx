/* Code simplifié ici. Le vrai code sera copié depuis ton projet */
export default function App() { return <div>Pause Cerveau</div>; }